package com.everis.examendos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Examen2AcademiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Examen2AcademiaApplication.class, args);
	}

}
